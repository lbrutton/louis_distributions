from setuptools import setup

setup(name='louis_distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      author = 'Louis Brutton',
      author_email = 'louisbrutton@gmail.com',
      packages=['louis_distributions'],
      zip_safe=False)